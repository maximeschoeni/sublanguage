<script type="text/javascript">
	var sublanguageTranslations = <?php echo json_encode($data) ?>;
	var currentPostId = <?php echo $post_id; ?>;
</script>